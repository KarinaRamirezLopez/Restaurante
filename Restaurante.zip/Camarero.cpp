#include "Camarero.h"
#include <iostream>

using namespace std;

Camarero::Camarero() : Empleado() {}

Camarero::Camarero(string nombre, string apellidoP, string apellidoM, int rfc, int salario, int nss)
    : Empleado(nombre, apellidoP, apellidoM, rfc, salario, nss) {}

void Camarero::Mostrar() const {
    cout << "Camarero - ";
    Empleado::Mostrar();
}
