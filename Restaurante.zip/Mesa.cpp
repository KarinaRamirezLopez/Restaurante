#include "Mesa.h"
#include <iostream>

using namespace std;

Mesa::Mesa() {
    cout << "Ingrese el número de la mesa: ";
    cin >> No_Mesa;
    cout << "Ingrese la capacidad de la mesa: ";
    cin >> Capacidad;
    cin.ignore(); // Limpiar el buffer del teclado
    cout << "Ingrese el estado de la mesa: ";
    cin >> Estado;
}

Mesa::Mesa(int no_mesa, int capacidad, string estado)
    : No_Mesa(no_mesa), Capacidad(capacidad), Estado(estado) {}

int Mesa::getNumeroMesa() const {
    return No_Mesa;
}

int Mesa::getCapacidad() const {
    return Capacidad;
}

string Mesa::getEstado() const {
    return Estado;
}

void Mesa::setEstado(string estado) {
    Estado = estado;
}

void Mesa::Mostrar_Mesa() const {
    cout << "Mesa Número: " << No_Mesa << ", Capacidad: " << Capacidad << ", Estado: " << Estado << endl;
}
