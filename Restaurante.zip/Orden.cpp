#include "Orden.h"
#include <iostream>

Orden::Orden(int idCliente, float precio, std::string nombrePlatillo, int cantidad)
    : IdCliente(idCliente), Precio(precio), Nombre_Platillo(nombrePlatillo), Cantidad(cantidad) {
    // Obtener la fecha y hora actual del sistema
    time_t now = time(0);
    tm *ltm = localtime(&now);

    // Guardar la hora y fecha
    Hora = ltm->tm_hour * 100 + ltm->tm_min; // Formato HHMM
    Fecha = (ltm->tm_year + 1900) * 10000 + (ltm->tm_mon + 1) * 100 + ltm->tm_mday; // Formato AAAAMMDD
}

void Orden::Mostrar_Orden() const {
    std::cout << "Orden realizada por Cliente ID: " << IdCliente << std::endl;
    std::cout << "Fecha: " << Fecha << std::endl;
    std::cout << "Hora: " << Hora << std::endl;
    std::cout << "Platillo: " << Nombre_Platillo << std::endl;
    std::cout << "Cantidad: " << Cantidad << std::endl;
    std::cout << "Precio por unidad: $" << Precio << std::endl;
    std::cout << "Total: $" << Precio * Cantidad << std::endl;
}
