#include <iostream>
#include <vector>
#include "Mesa.h"
#include "Cliente.h"
#include "Empleado.h"
#include "Reservacion.h"
#include "Orden.h"
#include "Chef.h"
#include "Camarero.h"
#include "Restaurante.h" 

using namespace std;

// Variables globales para almacenar las personas y mesas
vector<Cliente> clientes;
vector<Empleado> empleados;
vector<Chef> chefs;
vector<Camarero> camareros;
vector<Mesa> mesas;
vector<Reservacion> reservaciones;
vector<Orden> ordenes;

// Inicializar 7 mesas por defecto
void inicializarMesas() {
    mesas.push_back(Mesa(1, 2, "Disponible"));
    mesas.push_back(Mesa(2, 4, "Disponible"));
    mesas.push_back(Mesa(3, 4, "Disponible"));
    mesas.push_back(Mesa(4, 6, "Disponible"));
    mesas.push_back(Mesa(5, 6, "Disponible"));
    mesas.push_back(Mesa(6, 8, "Disponible"));
    mesas.push_back(Mesa(7, 10, "Disponible"));
}

// Funciones del menú
void ingresarPersona() {
    int opcion;
    cout << "Seleccione el tipo de persona:\n";
    cout << "1. Cliente\n";
    cout << "2. Empleado\n";
    cout << "Opción: ";
    cin >> opcion;
    cin.ignore(); // Limpiar el buffer del teclado

    string nombre, apellidoP, apellidoM;
    cout << "Nombre: ";
    getline(cin, nombre);
    cout << "Apellido Paterno: ";
    getline(cin, apellidoP);
    cout << "Apellido Materno: ";
    getline(cin, apellidoM);

    switch (opcion) {
        case 1: {
            Cliente nuevoCliente(nombre, apellidoP, apellidoM);
            clientes.push_back(nuevoCliente);
            cout << "Cliente ingresado. ID: " << nuevoCliente.getIdCliente() << endl;
            break;
        }
        case 2: {
            int tipoEmpleado, rfc, salario, nss;
            cout << "Seleccione el tipo de empleado:\n";
            cout << "1. Chef\n";
            cout << "2. Camarero\n";
            cout << "Opción: ";
            cin >> tipoEmpleado;
            cout << "RFC: ";
            cin >> rfc;
            cout << "Salario: ";
            cin >> salario;
            cout << "NSS: ";
            cin >> nss;
            cin.ignore(); // Limpiar el buffer del teclado

            if (tipoEmpleado == 1) {
                chefs.push_back(Chef(nombre, apellidoP, apellidoM, rfc, salario, nss));
                cout << "Chef ingresado." << endl;
            } else if (tipoEmpleado == 2) {
                camareros.push_back(Camarero(nombre, apellidoP, apellidoM, rfc, salario, nss));
                cout << "Camarero ingresado." << endl;
            } else {
                cout << "Opción no válida." << endl;
            }
            break;
        }
        default:
            cout << "Opción no válida." << endl;
    }
}

void ingresarMesa() {
    mesas.push_back(Mesa());
}

void mostrarMesasDisponibles() {
    cout << "Mesas disponibles:\n";
    for (const auto& mesa : mesas) {
        mesa.Mostrar_Mesa();
    }
}

void hacerReservacion() {
    int idCliente, noMesa, numPersonas;
    string fecha, hora;

    cout << "Ingrese el ID del cliente: ";
    cin >> idCliente;
    cout << "Mesas disponibles: " << endl;
    mostrarMesasDisponibles();
    cout << "Ingrese el número de la mesa (1-7): ";
    cin >> noMesa;
    cout << "Ingrese la fecha (AAAA-MM-DD): ";
    cin >> fecha;
    cout << "Ingrese la hora (HH:MM): ";
    cin >> hora;
    cout << "Ingrese el número de personas: ";
    cin >> numPersonas;
    cin.ignore(); // Limpiar el buffer del teclado

    // Validar que la mesa esté disponible y tenga capacidad suficiente
    for (auto& mesa : mesas) {
        if (mesa.getNumeroMesa() == noMesa) {
            if (mesa.getCapacidad() >= numPersonas) {
                if (mesa.getEstado() == "Disponible") {
                    reservaciones.push_back(Reservacion(idCliente, noMesa, fecha, hora, numPersonas));
                    mesa.setEstado("Ocupada");
                    cout << "Reservación realizada." << endl;
                    return;
                } else {
                    cout << "La mesa no está disponible, elija otra mesa." << endl;
                    return;
                }
            } else {
                cout << "La mesa no tiene suficiente capacidad." << endl;
                return;
            }
        }
    }

    cout << "Mesa no encontrada." << endl;
}

void modificarReservacion() {
    int idCliente;
    cout << "Ingrese el ID del cliente: ";
    cin >> idCliente;
    cin.ignore(); // Limpiar el buffer del teclado

    for (auto& reserva : reservaciones) {
        if (reserva.getIdCliente() == idCliente && reserva.getEstado() == "Activa") {
            string fecha, hora;
            int numPersonas;
            cout << "Ingrese la nueva fecha (AAAA-MM-DD): ";
            cin >> fecha;
            cout << "Ingrese la nueva hora (HH:MM): ";
            cin >> hora;
            cout << "Ingrese el nuevo número de personas: ";
            cin >> numPersonas;
            cin.ignore(); // Limpiar el buffer del teclado

            // Validar que la mesa tenga capacidad suficiente
            for (const auto& mesa : mesas) {
                if (mesa.getNumeroMesa() == reserva.getNumeroMesa()) {
                    if (mesa.getCapacidad() >= numPersonas) {
                        reserva.setFecha(fecha);
                        reserva.setHora(hora);
                        reserva.setNumPersonas(numPersonas);
                        cout << "Reservación modificada." << endl;
                        return;
                    } else {
                        cout << "La mesa no tiene suficiente capacidad. No se pudo modificar la reservación." << endl;
                        return;
                    }
                }
            }
        }
    }

    cout << "Reservación no encontrada." << endl;
}

void cancelarReservacion() {
    cout << "Reservaciones registradas:" << endl;
    for (const auto& reserva : reservaciones) {
        reserva.mostrar();
    }

    int idCliente;
    cout << "Ingrese el ID del cliente: ";
    cin >> idCliente;
    cin.ignore(); // Limpiar el buffer del teclado

    for (auto& reserva : reservaciones) {
        if (reserva.getIdCliente() == idCliente && reserva.getEstado() == "Activa") {
            reserva.cancelar();
            for (auto& mesa : mesas) {
                if (mesa.getNumeroMesa() == reserva.getNumeroMesa()) {
                    mesa.setEstado("Disponible");
                    break;
                }
            }
            cout << "Reservación cancelada." << endl;
            return;
        }
    }

    cout << "Reservación no encontrada." << endl;
}



void realizarOrden() {
    int idCliente;
    string nombrePlatillo;
    float precio;
    int cantidad;

    cout << "Ingrese el ID del cliente: ";
    cin >> idCliente;
    cin.ignore(); // Limpiar el buffer del teclado

    bool clienteEncontrado = false;
    for (const Cliente& cliente : clientes) {
        if (cliente.getIdCliente() == idCliente) {
            clienteEncontrado = true;
            break;
        }
    }

    if (clienteEncontrado) {
        cout << "Ingrese el nombre del platillo: ";
        getline(cin, nombrePlatillo);
        cout << "Ingrese el precio del platillo: ";
        cin >> precio;
        cout << "Ingrese la cantidad: ";
        cin >> cantidad;
        cin.ignore(); // Limpiar el buffer del teclado

        Orden nuevaOrden(idCliente, precio, nombrePlatillo, cantidad);
        ordenes.push_back(nuevaOrden);
        cout << "Orden realizada.\n";
        nuevaOrden.Mostrar_Orden();
    } else {
        cout << "Cliente no encontrado.\n";
    }
}

void mostrarOrdenes() {
    for (const Orden& orden : ordenes) {
        orden.Mostrar_Orden();
    }
}


void verPersonas() {
    cout << "Clientes registrados:" << endl;
    for (const auto& cliente : clientes) {
        cliente.Mostrar();
    }

    cout << "\nEmpleados registrados:" << endl;
    for (const auto& chef : chefs) {
        chef.Mostrar();
    }
    for (const auto& camarero : camareros) {
        camarero.Mostrar();
    }
}

void verMesas() {
    cout << "Mesas registradas:" << endl;
    for (const auto& mesa : mesas) {
        mesa.Mostrar_Mesa();
    }
}

void verReservaciones() {
    cout << "Reservaciones registradas:" << endl;
    for (const auto& reserva : reservaciones) {
        reserva.mostrar();
    }
}

int main() {
    setlocale(LC_CTYPE, "Spanish");

    Restaurante miRestaurante;
    inicializarMesas(); // Inicializar las mesas por defecto
    int opcion;

    do {
        cout << "\n======================================\n";
        cout << "          ¡¡Bienvenido!!\n";
        miRestaurante.Datos_restaurante();
        cout << "======================================\n";
        cout << "               Menu\n";
        cout << "--------------------------------------\n";
        cout << "| 1. Ingresar una persona            |\n";
        cout << "| 2. Ver personas registradas        |\n";
        cout << "| 3. Hacer reservación               |\n";
        cout << "| 4. Modificar reservación           |\n";
        cout << "| 5. Cancelar reservación            |\n";
        cout << "| 6. Ver reservaciones               |\n";
        cout << "| 7. Hacer pedido                    |\n";
        cout << "| 8. Ingresar una mesa               |\n";
        cout << "| 9. Ver mesas registradas           |\n";
        cout << "| 0. Salir                           |\n";
        cout << "--------------------------------------\n";
        cout << "Opción: ";
        cin >> opcion;
        cin.ignore(); // Limpiar el buffer del teclado

        switch (opcion) {
            case 1:
                ingresarPersona();
                break;
            case 2:
                verPersonas();
                break;
            case 3:
                hacerReservacion();
                break;
            case 4:
                modificarReservacion();
                break;
            case 5:
                cancelarReservacion();
                break;
            case 6:
                verReservaciones();
                break;    
            case 7:
                realizarOrden();
                break;
            case 8:
                ingresarMesa();
                break;
            case 9:
                verMesas();
                break;
            case 0:
                cout << "Saliendo...\nAdios:)" << endl;
                break;
            default:
                cout << "Ingresa una opción valida." << endl;
        }
    } while (opcion != 0);

    return 0;
}