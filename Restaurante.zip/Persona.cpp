// Persona.cpp
#include "Persona.h"
#include <iostream>

using namespace std;

Persona::Persona() {
    cout << "------ Nombre: ";
    getline(cin, Nombre);
    cout << "\n------ Apellido Paterno: ";
    getline(cin, Apellido_P);
    cout << "\n------ Apellido Materno: ";
    getline(cin, Apellido_M);
}

Persona::Persona(string nombre, string apellidoP, string apellidoM)
    : Nombre(nombre), Apellido_P(apellidoP), Apellido_M(apellidoM) {}

string Persona::getNombre() const {
    return Nombre;
}

string Persona::getApellidoP() const {
    return Apellido_P;
}

string Persona::getApellidoM() const {
    return Apellido_M;
}

void Persona::Mostrar() const {
    cout << "Nombre: " << Nombre << " " << Apellido_P << " " << Apellido_M << endl;
}


