#include "Reservacion.h"
#include <iostream>

using namespace std;

Reservacion::Reservacion(int idCliente, int no_mesa, string fecha, string hora, int numPersonas)
    : idCliente(idCliente), No_Mesa(no_mesa), Fecha(fecha), Hora(hora), NumPersonas(numPersonas), Estado("Activa") {}

int Reservacion::getIdCliente() const {
    return idCliente;
}

int Reservacion::getNumeroMesa() const {
    return No_Mesa;
}

string Reservacion::getFecha() const {
    return Fecha;
}

string Reservacion::getHora() const {
    return Hora;
}

int Reservacion::getNumPersonas() const {
    return NumPersonas;
}

string Reservacion::getEstado() const {
    return Estado;
}

void Reservacion::setFecha(string fecha) {
    Fecha = fecha;
}

void Reservacion::setHora(string hora) {
    Hora = hora;
}

void Reservacion::setNumPersonas(int numPersonas) {
    NumPersonas = numPersonas;
}

void Reservacion::cancelar() {
    Estado = "Cancelada";
}

void Reservacion::mostrar() const {
    cout << "ID Cliente: " << idCliente << endl;
    cout << "Mesa Número: " << No_Mesa << endl;
    cout << "Fecha: " << Fecha << endl;
    cout << "Hora: " << Hora << endl;
    cout << "Número de Personas: " << NumPersonas << endl;
    cout << "Estado: " << Estado << endl;
}

