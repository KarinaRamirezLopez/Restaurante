#include "Empleado.h"
#include <iostream>

//#include "Empleado.h"

using namespace std;

Empleado::Empleado() : Persona() {
    cout << "------ RFC: ";
    cin >> RFC;
    cout << "\n------ Salario: ";
    cin >> Salario;
    cout << "\n------ NSS: ";
    cin >> NSS;
    cin.ignore(); // Limpiar el buffer del teclado
}

Empleado::Empleado(string nombre, string apellidoP, string apellidoM, int rfc, int salario, int nss)
    : Persona(nombre, apellidoP, apellidoM), RFC(rfc), Salario(salario), NSS(nss) {}

int Empleado::getRFC() const {
    return RFC;
}

int Empleado::getSalario() const {
    return Salario;
}

int Empleado::getNSS() const {
    return NSS;
}

void Empleado::Mostrar() const {
    Persona::Mostrar();
    cout << "RFC: " << RFC << ", Salario: " << Salario << ", NSS: " << NSS << endl;
}
