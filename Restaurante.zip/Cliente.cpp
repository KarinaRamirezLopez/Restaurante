#include "Cliente.h"
#include <iostream>
#include <string>

using namespace std;

int Cliente::contadorClientes = 0;

Cliente::Cliente() : Persona() {
    idCliente = ++contadorClientes;
}

Cliente:: Cliente (string nombre, string apellidoP, string apellidoM)
    : Persona(nombre, apellidoP, apellidoM) {
    idCliente = ++contadorClientes;
}

int Cliente::getIdCliente() const {
    return idCliente;
}

void Cliente::Mostrar() const {
    std:: cout << "\nCliente ID: " << idCliente << " - ";
    Persona::Mostrar();
}
