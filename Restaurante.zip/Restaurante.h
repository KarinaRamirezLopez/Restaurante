#ifndef RESTAURANTE_H
#define RESTAURANTE_H

#include <string>
#include <iostream>

class Restaurante {
private:
    std::string Nombre_res;
    std::string Direccion;
    std::string Telefono;

public:
    Restaurante();
    std::string getNombre() const;
    std::string getDireccion() const;
    std::string getTelefono() const;
    void Datos_restaurante() const;
};

#endif // RESTAURANTE_H
