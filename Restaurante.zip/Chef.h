#ifndef CHEF_H
#define CHEF_H

#include "Empleado.h"
#include <iostream>

class Chef : public Empleado {
public:
    Chef();
    Chef(std::string nombre, std::string apellidoP, std::string apellidoM, int rfc, int salario, int nss);
    void Mostrar() const override;
};

#endif // CHEF_H



