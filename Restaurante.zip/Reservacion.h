#ifndef RESERVACION_H
#define RESERVACION_H

#include <string>
#include <iostream>

class Reservacion {
private:
    int idCliente;
    int No_Mesa;
    std::string Fecha;
    std::string Hora;
    int NumPersonas;
    std::string Estado;

public:
    Reservacion(int idCliente, int no_mesa, std::string fecha, std::string hora, int numPersonas);

    int getIdCliente() const;
    int getNumeroMesa() const;
    std::string getFecha() const;
    std::string getHora() const;
    int getNumPersonas() const;
    std::string getEstado() const;

    void setFecha(std::string fecha);
    void setHora(std::string hora);
    void setNumPersonas(int numPersonas);
    void cancelar();
    void mostrar() const;
};

#endif // RESERVACION_H
