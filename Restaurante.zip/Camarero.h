#ifndef CAMARERO_H
#define CAMARERO_H

#include "Empleado.h"
#include <iostream>

class Camarero : public Empleado {
public:
    Camarero();
    Camarero(std::string nombre, std::string apellidoP, std::string apellidoM, int rfc, int salario, int nss);
    void Mostrar() const override;
};

#endif // CAMARERO_H
