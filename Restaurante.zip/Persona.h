#ifndef PERSONA_H
#define PERSONA_H

#include <iostream>
#include <string>

class Persona {
protected:
    std::string Nombre;
    std::string Apellido_P;
    std::string Apellido_M;

public:
    Persona();
    Persona(std::string nombre, std::string apellidoP, std::string apellidoM);
    std::string getNombre() const;
    std::string getApellidoP() const;
    std::string getApellidoM() const;
    virtual void Mostrar() const;
};

#endif // PERSONA_H

