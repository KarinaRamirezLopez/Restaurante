#ifndef EMPLEADO_H
#define EMPLEADO_H

#include "Persona.h"
#include <iostream>

class Empleado : public Persona {
private:
    int RFC;
    int Salario;
    int NSS;

public:
    Empleado();
    Empleado(std::string nombre, std::string apellidoP, std::string apellidoM, int rfc, int salario, int nss);
    int getRFC() const;
    int getSalario() const;
    int getNSS() const;
    void Mostrar() const override;
};

#endif // EMPLEADO_H
