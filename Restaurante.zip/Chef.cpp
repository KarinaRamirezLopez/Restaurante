#include "Chef.h"
#include <iostream>

using namespace std;

Chef::Chef() : Empleado() {}

Chef::Chef(string nombre, string apellidoP, string apellidoM, int rfc, int salario, int nss)
    : Empleado(nombre, apellidoP, apellidoM, rfc, salario, nss) {}

void Chef::Mostrar() const {
    cout << "Chef - ";
    Empleado::Mostrar();
}
