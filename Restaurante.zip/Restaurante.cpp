#include "Restaurante.h"
#include <iostream>

using namespace std;

Restaurante::Restaurante() {
    cout << "------ Ingresa el nombre del restaurante: ";
    getline(cin, Nombre_res);
    cout << "\n------ Ingresa la dirección: ";
    getline(cin, Direccion);
    cout << "\n------ Ingresa el numero telefónico: ";
    getline(cin, Telefono);
}

string Restaurante::getNombre() const {
    return Nombre_res;
}

string Restaurante::getDireccion() const {
    return Direccion;
}

string Restaurante::getTelefono() const {
    return Telefono;
}

void Restaurante::Datos_restaurante() const {
    cout << "       Restaurante " << Nombre_res << endl;
    cout << "       Direccion: " << Direccion << endl;
    cout << "       Telefono: " << Telefono << endl;
}
