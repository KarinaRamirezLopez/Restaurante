#ifndef ORDEN_H
#define ORDEN_H

#include <iostream>
#include <string>
#include <ctime>

class Orden {
private:
    int IdCliente;
    float Precio;
    std::string Nombre_Platillo;
    int Cantidad;
    int Fecha;
    int Hora;

public:
    Orden(int idCliente, float precio, std::string nombrePlatillo, int cantidad);
    void Mostrar_Orden() const;
};

#endif // ORDEN_H
