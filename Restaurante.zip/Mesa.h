#ifndef MESA_H
#define MESA_H

#include <string>
#include <iostream>

class Mesa {
private:
    int No_Mesa;
    int Capacidad;
    std::string Estado;

public:
    Mesa();
    Mesa(int no_mesa, int capacidad, std::string estado);
    int getNumeroMesa() const;
    int getCapacidad() const;
    std::string getEstado() const;
    void setEstado(std::string estado);
    void Mostrar_Mesa() const;
};

#endif // MESA_H

