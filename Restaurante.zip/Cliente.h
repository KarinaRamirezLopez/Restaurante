#ifndef CLIENTE_H
#define CLIENTE_H

#include "Persona.h"
#include <iostream>
#include <string>

class Cliente : public Persona {
private:
    int idCliente;
    static int contadorClientes;

public:
    // Constructors
    Cliente();
    Cliente(std::string nombre, std::string apellidoP, std::string apellidoM);
    
    // Getter for idCliente
    int getIdCliente() const;
    
    // Override the Mostrar method
    void Mostrar() const override;
};

#endif // CLIENTE_H

